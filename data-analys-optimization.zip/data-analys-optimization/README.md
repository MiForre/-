## Дисципліна "Спеціальні мови програмування", тема "Бібліотека для збору, аналізу та оптимізації даних", Редько Юлія

# 

Ця бібліотека розроблена для роботи з даними про обсяги продажів, час роботи та інші важливі параметри. Вона містить класи та методи для збору, аналізу та оптимізації цих даних.

## Вміст

- `data_collection.py`: Клас для збору даних про обсяги продажів, час роботи та інші параметри.
- `data_analysis.py`: Клас для аналізу зібраних даних та їх візуалізації.
- `optimization.py`: Клас для оптимізації графіку роботи і асортименту продукції.
- `other_functions.py`: Додаткові функції, такі як прогнозування продажів та аналіз маркетингу.

## Використання

1. Імпорт бібліотеки:
    ```python
    from my_data_library import DataCollector, DataAnalyzer, Optimizer, OtherFunctions
    ```

2. Приклад використання:

    ```python
    # Збір даних
    collector = DataCollector()
    collector.collect_sales_data([100, 150, 200])
    collector.collect_work_time_data([8, 9, 7])

    # Аналіз даних
    analyzer = DataAnalyzer([10, 20, 30, 25])
    mean_value = analyzer.process_data()
    analyzer.visualize_data()

    # Оптимізація
    optimizer = Optimizer([8, 7, 9, 6, 10])
    optimal_schedule = optimizer.optimize_schedule()

    # Додаткові функції
    functions = OtherFunctions([100, 150, 200])
    sales_forecast = functions.sales_forecasting()
    functions.marketing_analysis()
    ```

## Важливо

Ця бібліотека містить базовий функціонал. Для конкретних бізнес-задач, може знадобитися розширення функціоналу та оптимізація методів відповідно до потреб проєкту.
