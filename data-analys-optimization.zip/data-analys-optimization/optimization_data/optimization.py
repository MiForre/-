class Optimizer:
    def __init__(self, data):
        self.data = data

    def optimize_schedule(self):
        # Приклад: визначення оптимального часу роботи
        max_value = max(self.data)
        optimal_time = self.data.index(max_value)
        return optimal_time

    def optimize_product_assortment(self):
        # Приклад: знаходження найпопулярнішого продукту
        from collections import Counter
        counter = Counter(self.data)
        most_common = counter.most_common(1)
        return most_common[0][0]

def example_optimization():
    # Приклад даних для оптимізації
    schedule_data = [8, 7, 9, 6, 10]
    product_data = ['A', 'B', 'A', 'C', 'A']

    # Створення екземпляру класу та оптимізація
    optimizer = Optimizer(schedule_data)
    optimal_schedule = optimizer.optimize_schedule()

    product_optimizer = Optimizer(product_data)
    optimal_product = product_optimizer.optimize_product_assortment()

    # Виведення результатів оптимізації
    print("Optimal Schedule:", optimal_schedule)
    print("Optimal Product Assortment:", optimal_product)
