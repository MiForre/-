class DataCollector:
    def __init__(self):
        self.sales_data = []
        self.work_time_data = []

    def collect_sales_data(self, sales):
        self.sales_data.extend(sales)

    def collect_work_time_data(self, work_time):
        self.work_time_data.extend(work_time)

    def get_sales_data(self):
        return self.sales_data

    def get_work_time_data(self):
        return self.work_time_data

def example_data_collection():
    # Створення екземпляру класу
    collector = DataCollector()

    # Збір даних про продажі
    sales_data = [100, 150, 200, 180, 220]
    collector.collect_sales_data(sales_data)

    # Збір даних про час роботи
    work_time_data = [8, 9, 7, 8, 10]
    collector.collect_work_time_data(work_time_data)

    # Виведення зібраних даних
    print("Sales Data:", collector.get_sales_data())
    print("Work Time Data:", collector.get_work_time_data())
