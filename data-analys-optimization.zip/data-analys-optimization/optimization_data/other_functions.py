class OtherFunctions:
    def __init__(self, data):
        self.data = data

    def sales_forecasting(self):
        # Приклад: простий прогноз продажів
        return sum(self.data) / len(self.data) if self.data else None

    def marketing_analysis(self):
        # Приклад: відображення аналізу маркетингових даних
        print("Marketing Analysis:")
        for item in self.data:
            print(item)

def example_other_functions():
    # Приклад даних для аналізу
    sales_data = [100, 150, 200, 180, 220]
    marketing_data = ['Ad Campaign A', 'Ad Campaign B', 'Ad Campaign C']

    # Створення екземпляру класу та виконання функцій
    func = OtherFunctions(sales_data)
    sales_forecast = func.sales_forecasting()

    marketing_func = OtherFunctions(marketing_data)
    marketing_func.marketing_analysis()

    # Виведення результатів функцій
    print("Sales Forecast:", sales_forecast)
