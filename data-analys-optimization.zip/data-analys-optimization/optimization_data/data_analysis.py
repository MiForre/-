class DataAnalyzer:
    def __init__(self, data):
        self.data = data

    def process_data(self):
        # Приклад: підрахунок середнього значення
        return sum(self.data) / len(self.data) if self.data else None

    def visualize_data(self):
        # Приклад: проста візуалізація даних
        import matplotlib.pyplot as plt
        plt.plot(self.data)
        plt.title('Data Visualization')
        plt.xlabel('X-axis')
        plt.ylabel('Y-axis')
        plt.show()

def example_data_analysis():
    # Приклад даних для аналізу
    data = [10, 20, 30, 25, 35]

    # Створення екземпляру класу та аналіз даних
    analyzer = DataAnalyzer(data)
    mean_value = analyzer.process_data()

    # Виведення результатів аналізу
    print("Mean Value:", mean_value)

    # Візуалізація даних
    analyzer.visualize_data()
